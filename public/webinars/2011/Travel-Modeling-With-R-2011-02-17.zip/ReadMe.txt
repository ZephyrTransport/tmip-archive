This the TMIP Travel Modeling with R introduction
2/17/2011
Author and Presenter: Jeremy Raw, jeremy.raw@dot.gov

Files in this distribution:

ReadMe.txt
Travel-Modeling-With-R.pdf
Travel-Modeling-With-R.R
Travel-Modeling-With-R.Rnw
RGui.png
Rlogo.png
alx.network.Rdata
Sweave.sty

## Presentation

The presentation is in Trave-Modeling-With-R.pdf file.

## R code

You'll need to install R in order to run the presentation.
You'll also need to install the "sp" package to play with
the mapping functions.  You'll probably also want "maptools".

install.packages(c("sp","maptools")) # should do it...

The R code from the presentation is in Travel-Modeling-With-R.R
You may run this code by starting R and using File\Change dir...
to move to the folder containing these files.

In addition, you'll need the NHTS data, which you can retrieve
by uncommenting and executing the code that downloads and
extracts that file.

For some indeterminate period, you can find the built file here:
http://dl.dropbox.com/u/19259843/NHTS.Rdata

(If that link stops working, or if you want to do real analyses
that are certain to be using the correct data, you'll need to
download the data directly from the NHTS site).

Once all is in order use this R command:

source("Travel-Modeling-With-R.R")

The results of that will not be particularly informative, but
you can edit and extract parts of the file to explore further.

## Rebuilding the presentation

These files are needed only to build the presentation:

RGui.png  (Screen shot of the GUI)
Rlogo.png (R Logo)
alx.network.Rdata (sample spatial data from Alexandria, VA via TRANSIMS)
Sweave.sty (Support file for building the presentation)

Once you have created NHTS.Rdata, you don't need to do the
download again.

To build the presentation, you will need a working LaTeX
installation, with the "beamer" package and other supports as
noted in the preamble of 'Travel-Modeling-With-R.Rnw".  The
MikTeX system for Windows (http://miktex.org) will automatically
install many packages, and cooperates nicely with R.

The following R code rebuilds the presentation

#################################################################
# R code follows

library(tools)  # package with texi2dvi

Sweave(paste(file,".Rnw",sep=""))  # Execute R code to make .tex file

texi2dvi(paste(file,".tex",sep=""),pdf=T)  # Process .tex into .pdf

Stangle("Travel-Modeling-With-R.Rnw",annotate=FALSE) # extract R code

# End of R code
#################################################################
