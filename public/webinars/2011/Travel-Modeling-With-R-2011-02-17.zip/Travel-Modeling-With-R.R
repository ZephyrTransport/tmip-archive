## #line 184 "Travel-Modeling-With-R.Rnw"
## # Lines starting like this (## ) are commented code
## # Remove the initial ## to execute in R
## "Ta-dah!"


#line 192 "Travel-Modeling-With-R.Rnw"
2


#line 196 "Travel-Modeling-With-R.Rnw"
3.1415924


#line 200 "Travel-Modeling-With-R.Rnw"
"Hello, world"


#line 212 "Travel-Modeling-With-R.Rnw"
print(2)


#line 218 "Travel-Modeling-With-R.Rnw"
length(2)  # One number is still a vector


## #line 224 "Travel-Modeling-With-R.Rnw"
## help("length")


#line 232 "Travel-Modeling-With-R.Rnw"
c(1,2,3,4)  # concatenate values
1:4


#line 241 "Travel-Modeling-With-R.Rnw"
c(1,2,3,4) * 2


#line 247 "Travel-Modeling-With-R.Rnw"
c(8,27,64) / c(2,3,4)


#line 254 "Travel-Modeling-With-R.Rnw"
runif(4)  # 4 draws from the interval [0,1]


#line 258 "Travel-Modeling-With-R.Rnw"
rnorm(4)  # 4 draws from N(0,1)


#line 262 "Travel-Modeling-With-R.Rnw"
dnorm(1.8,mean=2,sd=0.5) # normal density


#line 266 "Travel-Modeling-With-R.Rnw"
sample(5)     # 5 integers in random order
sample(56,5)  # 5 random integers between 1 and 56
sample(46,1)  # 1 random integer between 1 and 46


#line 277 "Travel-Modeling-With-R.Rnw"
plot(dnorm,from=-3,to=3,n=40,
     col="blue",type='o',lwd=2,
     main='Normal Distribution ~ N(0,1)')


#line 288 "Travel-Modeling-With-R.Rnw"
seq4 <- 1:4


#line 294 "Travel-Modeling-With-R.Rnw"
1:4 -> seq4.a


#line 300 "Travel-Modeling-With-R.Rnw"
seq4.eq = 1:4


## #line 306 "Travel-Modeling-With-R.Rnw"
## objects()


#line 309 "Travel-Modeling-With-R.Rnw"
objects(pattern='^seq4')


## #line 314 "Travel-Modeling-With-R.Rnw"
## ls()


#line 317 "Travel-Modeling-With-R.Rnw"
ls(pattern='^seq4')


#line 327 "Travel-Modeling-With-R.Rnw"
v <- c('A','B','C','D')
v[3]      # A single element


#line 332 "Travel-Modeling-With-R.Rnw"
v[1:2]    # A pair of elements


#line 336 "Travel-Modeling-With-R.Rnw"
idx <- c(1,4)
v[idx] # Using a vector to index a vector


#line 341 "Travel-Modeling-With-R.Rnw"
v[5]      # Oops, out of bounds!


## #line 349 "Travel-Modeling-With-R.Rnw"
## v <- c('A','B','C','D')
## v[c(1,2,1,3,1,2)]


#line 354 "Travel-Modeling-With-R.Rnw"
#line 349 "Travel-Modeling-With-R.Rnw#from line#354#"
v <- c('A','B','C','D')
v[c(1,2,1,3,1,2)]
#line 355 "Travel-Modeling-With-R.Rnw"


#line 360 "Travel-Modeling-With-R.Rnw"
f <- factor( c("HBO","HBO","HBW","NHB","HBW") )
f
as.integer(f)


#line 372 "Travel-Modeling-With-R.Rnw"
m <- matrix( 1:9, ncol=3 )
m


#line 377 "Travel-Modeling-With-R.Rnw"
m <- matrix( 1:9, ncol=3, byrow=TRUE )
m


#line 387 "Travel-Modeling-With-R.Rnw"
t(m)         # transpose
diag(m)      # diagonal vector
diag(m) <- 0 # set diagonal to zero


#line 393 "Travel-Modeling-With-R.Rnw"
det(m)       # determinant
eigen(m)     # eigenvalues


#line 405 "Travel-Modeling-With-R.Rnw"
m[2:3,2:3] # Matrix subset
m[,3]      # Vector (drops unit dimensions)


#line 410 "Travel-Modeling-With-R.Rnw"
m[2,3]     # Scalar (drops both dimensions)
m[2,3,drop=FALSE] # 1 x 1 matrix


#line 422 "Travel-Modeling-With-R.Rnw"
a.list <- list(
    Sequence=seq4,
    Text=LETTERS[1:10]
    )
a.list


#line 434 "Travel-Modeling-With-R.Rnw"
names(a.list)


#line 440 "Travel-Modeling-With-R.Rnw"
str(a.list)


#line 449 "Travel-Modeling-With-R.Rnw"
a.list[2]    # second element as list


#line 453 "Travel-Modeling-With-R.Rnw"
a.list[[2]]  # second element as vector


#line 457 "Travel-Modeling-With-R.Rnw"
a.list$Text  # List element by Name


#line 461 "Travel-Modeling-With-R.Rnw"
a.list[["Text"]]  # Also by name


#line 473 "Travel-Modeling-With-R.Rnw"
seq5 <- 2:5
df <- data.frame(N=seq5,S=seq5^2,C=seq5^3)


#line 478 "Travel-Modeling-With-R.Rnw"
names(df)    # The list of columns (or fields)


#line 483 "Travel-Modeling-With-R.Rnw"
df


#line 494 "Travel-Modeling-With-R.Rnw"
df[2:3,2:3] # Subset
df[2]       # just the second column
df[[2]]     # second column as a vector


#line 500 "Travel-Modeling-With-R.Rnw"
df[2,]     # just the second row


#line 504 "Travel-Modeling-With-R.Rnw"
df$S       # vector from 'S' column
df[sample(nrow(df),1), ]  # random row


## #line 524 "Travel-Modeling-With-R.Rnw"
## # Remove the comments (## ) from the following to download
## # NHTS data and load it into R.  Once you have NHTS.Rdata
## # you don't need this code any more (just use the 'load' code)


## #line 529 "Travel-Modeling-With-R.Rnw"
## download.file(
##     "http://nhts.ornl.gov/2009/download/Ascii.zip",
##     "NHTS-2009-ASCII.zip"
##     )
## unzip("NHTS-2009-ASCII.zip",exdir="NHTS-2009")
## dir("NHTS-2009")  # show files in the directory


## #line 537 "Travel-Modeling-With-R.Rnw"
## hh  <- read.csv("NHTS-2009/hhv2pub.csv")
## veh <- read.csv("NHTS-2009/vehv2pub.csv")
## day <- read.csv("NHTS-2009/dayv2pub.csv")
## per <- read.csv("NHTS-2009/perv2pub.csv")
## save(per,hh,veh,day,file="NHTS.Rdata")


## #line 545 "Travel-Modeling-With-R.Rnw"
## load("NHTS.Rdata")   # reload later


#line 548 "Travel-Modeling-With-R.Rnw"
if (!exists('hh')) load("NHTS.Rdata") # shortcut


#line 572 "Travel-Modeling-With-R.Rnw"
if (memory.limit()<2047) memory.limit(2047) # create elbow room


#line 575 "Travel-Modeling-With-R.Rnw"
day.wt <- day[c("HOUSEID","WTTRDFIN",
                "TRIPPURP","TRVLCMIN")]
hh.wt <- hh[c("HOUSEID","WTHHFIN","HHSIZE")]
hh.wt$HHBIN <- with(hh.wt,{
    cut(HHSIZE,
        breaks=c(0,1,2,3,
        max(HHSIZE)),
        labels=c("1","2","3","4+"),
        ordered_result=TRUE)
    })


#line 588 "Travel-Modeling-With-R.Rnw"
# join the trip and household tables
trips <- merge(day.wt,hh.wt,by="HOUSEID")
trips$PURPOSE <- factor(trips$TRIPPURP,
                              exclude=c("-9"))


#line 594 "Travel-Modeling-With-R.Rnw"
# Aggregate the results
trips.person <- with(trips,{
    aggregate(
        trips["WTTRDFIN"],
        by=list(PURPOSE=PURPOSE,HHBIN=HHBIN),
        sum
        )
    })
trips.person <- reshape(
    trips.person,direction="wide",
    idvar="HHBIN",timevar="PURPOSE",
    v.names="WTTRDFIN"
    )
row.names(trips.person) <-
        levels(trips.person$HHBIN)


#line 611 "Travel-Modeling-With-R.Rnw"
trips.person.day <-
 data.matrix(trips.person[,2:length(trips.person)]/365)
dimnames(trips.person.day) <-
   list(
      HHSIZE=levels(trips.person$HHBIN),
      PURPOSE=levels(trips$PURPOSE)
      )
trips.hh <- with(hh.wt,{
    aggregate(
        hh.wt["WTHHFIN"],
        by=list(HHBIN=HHBIN),
        sum
        )
    })


#line 627 "Travel-Modeling-With-R.Rnw"
trips.per.person.per.day <-
   sweep(trips.person.day,1,trips.hh$WTHHFIN,FUN="/")
sum.trips.day <- colSums(trips.person.day)
sum.hh <- sum(trips.hh$WTHHFIN)
mean.trips.per.day.by.purpose <- sum.trips.day/sum.hh
mean.trips.per.day <- sum(mean.trips.per.day.by.purpose)


#line 640 "Travel-Modeling-With-R.Rnw"
print(trips.per.person.per.day)


#line 647 "Travel-Modeling-With-R.Rnw"
print(mean.trips.per.day.by.purpose)


#line 654 "Travel-Modeling-With-R.Rnw"
print(mean.trips.per.day)


## #line 669 "Travel-Modeling-With-R.Rnw"
## #line 575 "Travel-Modeling-With-R.Rnw#from line#669#"
## day.wt <- day[c("HOUSEID","WTTRDFIN",
##                 "TRIPPURP","TRVLCMIN")]
## hh.wt <- hh[c("HOUSEID","WTHHFIN","HHSIZE")]
## hh.wt$HHBIN <- with(hh.wt,{
##     cut(HHSIZE,
##         breaks=c(0,1,2,3,
##         max(HHSIZE)),
##         labels=c("1","2","3","4+"),
##         ordered_result=TRUE)
##     })
## #line 670 "Travel-Modeling-With-R.Rnw"


## #line 673 "Travel-Modeling-With-R.Rnw"
## #line 588 "Travel-Modeling-With-R.Rnw#from line#673#"
## # join the trip and household tables
## trips <- merge(day.wt,hh.wt,by="HOUSEID")
## trips$PURPOSE <- factor(trips$TRIPPURP,
##                               exclude=c("-9"))
## #line 674 "Travel-Modeling-With-R.Rnw"


## #line 677 "Travel-Modeling-With-R.Rnw"
## #line 594 "Travel-Modeling-With-R.Rnw#from line#677#"
## # Aggregate the results
## trips.person <- with(trips,{
##     aggregate(
##         trips["WTTRDFIN"],
##         by=list(PURPOSE=PURPOSE,HHBIN=HHBIN),
##         sum
##         )
##     })
## trips.person <- reshape(
##     trips.person,direction="wide",
##     idvar="HHBIN",timevar="PURPOSE",
##     v.names="WTTRDFIN"
##     )
## row.names(trips.person) <-
##         levels(trips.person$HHBIN)
## #line 678 "Travel-Modeling-With-R.Rnw"


## #line 681 "Travel-Modeling-With-R.Rnw"
## #line 611 "Travel-Modeling-With-R.Rnw#from line#681#"
## trips.person.day <-
##  data.matrix(trips.person[,2:length(trips.person)]/365)
## dimnames(trips.person.day) <-
##    list(
##       HHSIZE=levels(trips.person$HHBIN),
##       PURPOSE=levels(trips$PURPOSE)
##       )
## trips.hh <- with(hh.wt,{
##     aggregate(
##         hh.wt["WTHHFIN"],
##         by=list(HHBIN=HHBIN),
##         sum
##         )
##     })
## #line 682 "Travel-Modeling-With-R.Rnw"


## #line 685 "Travel-Modeling-With-R.Rnw"
## #line 627 "Travel-Modeling-With-R.Rnw#from line#685#"
## trips.per.person.per.day <-
##    sweep(trips.person.day,1,trips.hh$WTHHFIN,FUN="/")
## sum.trips.day <- colSums(trips.person.day)
## sum.hh <- sum(trips.hh$WTHHFIN)
## mean.trips.per.day.by.purpose <- sum.trips.day/sum.hh
## mean.trips.per.day <- sum(mean.trips.per.day.by.purpose)
## #line 686 "Travel-Modeling-With-R.Rnw"


#line 696 "Travel-Modeling-With-R.Rnw"
trips$SIMPPURP <- trips$PURPOSE
recode <- which(
	! (   trips$PURPOSE %in% c("HBW","NHB"))
        & !is.na(trips$PURPOSE )
    )
trips$SIMPPURP[recode] <- "HBO"
trips$SIMPPURP <- factor(trips$SIMPPURP)


#line 706 "Travel-Modeling-With-R.Rnw"
trips$TRIPLEN.1 <- as.integer(
    cut( trips$TRVLCMIN,
         breaks=seq(0,120,1),
         ORDERED_RESULT=TRUE )
    )
trip.dist.1 <- with( trips, {
    aggregate(
        data.frame(Trips=WTTRDFIN/365000),
        by=list(Purpose=SIMPPURP,TRIPLEN=TRIPLEN.1),
        sum)
    })


#line 720 "Travel-Modeling-With-R.Rnw"
min.5 <- which(trips$TRVLCMIN%%5<0.1)
trips[min.5,"TRIPLEN.5"] <- as.integer(
    cut(
        trips[min.5,"TRVLCMIN"],
        breaks=seq(0,120,5),
        ordered_result=TRUE,
        )
    ) * 5

trip.dist.5 <- with( trips[min.5,], {
    aggregate(
        data.frame(Trips=WTTRDFIN/365000),
        by=list(Purpose=SIMPPURP,TRIPLEN=TRIPLEN.5),
        sum)
    })


#line 738 "Travel-Modeling-With-R.Rnw"
nhb.5 = which(trip.dist.5$Purpose=="NHB")
hbw.5 = which(trip.dist.5$Purpose=="HBW")
hbo.5 = which(trip.dist.5$Purpose=="HBO")
hbo.1 = which(trip.dist.1$Purpose=="HBO")


#line 749 "Travel-Modeling-With-R.Rnw"
plot(trip.dist.1[hbo.1,2:3],type='o',
     col="gray",pch=15,cex=0.5,
     main="HBO Trip Lengths",
     xlab="Reported Trip Time in Minutes",
	 ylab="Daily Trips (1000s)")
points(trip.dist.5[hbo.5,2:3],type='o',
       col="blue",pch=16,cex=0.5)
legend(75,100000,
       c("5-minute Times","1-minute Times"),
       col=c("blue","lightgray"),pch=c(16,15),
       pt.cex=0.5,lty=1)


#line 766 "Travel-Modeling-With-R.Rnw"
plot(trip.dist.5[hbo.5,2:3],type='o',
     col="blue",pch=16,cex=0.5,
     main="Trip Length Frequency Distribution",
     sub="By Purpose, 5-minute Reports Only",
     ylab="Daily Trips (1000s)")
points(trip.dist.5[nhb.5,2:3],type='o',
       col="red",pch=15,cex=0.5)
points(trip.dist.5[hbw.5,2:3],type='o',
       col="green",pch=14,cex=0.5)
legend(90,100000,c("HBO","NHB","HBW"),
       col=c("blue","red","green"),
       pch=c(16,15,14),pt.cex=0.5,lty=1)


## #line 788 "Travel-Modeling-With-R.Rnw"
## #line 696 "Travel-Modeling-With-R.Rnw#from line#788#"
## trips$SIMPPURP <- trips$PURPOSE
## recode <- which(
## 	! (   trips$PURPOSE %in% c("HBW","NHB"))
##         & !is.na(trips$PURPOSE )
##     )
## trips$SIMPPURP[recode] <- "HBO"
## trips$SIMPPURP <- factor(trips$SIMPPURP)
## #line 789 "Travel-Modeling-With-R.Rnw"


## #line 792 "Travel-Modeling-With-R.Rnw"
## #line 706 "Travel-Modeling-With-R.Rnw#from line#792#"
## trips$TRIPLEN.1 <- as.integer(
##     cut( trips$TRVLCMIN,
##          breaks=seq(0,120,1),
##          ORDERED_RESULT=TRUE )
##     )
## trip.dist.1 <- with( trips, {
##     aggregate(
##         data.frame(Trips=WTTRDFIN/365000),
##         by=list(Purpose=SIMPPURP,TRIPLEN=TRIPLEN.1),
##         sum)
##     })
## #line 793 "Travel-Modeling-With-R.Rnw"


## #line 796 "Travel-Modeling-With-R.Rnw"
## #line 720 "Travel-Modeling-With-R.Rnw#from line#796#"
## min.5 <- which(trips$TRVLCMIN%%5<0.1)
## trips[min.5,"TRIPLEN.5"] <- as.integer(
##     cut(
##         trips[min.5,"TRVLCMIN"],
##         breaks=seq(0,120,5),
##         ordered_result=TRUE,
##         )
##     ) * 5
## 
## trip.dist.5 <- with( trips[min.5,], {
##     aggregate(
##         data.frame(Trips=WTTRDFIN/365000),
##         by=list(Purpose=SIMPPURP,TRIPLEN=TRIPLEN.5),
##         sum)
##     })
## #line 797 "Travel-Modeling-With-R.Rnw"


## #line 800 "Travel-Modeling-With-R.Rnw"
## #line 738 "Travel-Modeling-With-R.Rnw#from line#800#"
## nhb.5 = which(trip.dist.5$Purpose=="NHB")
## hbw.5 = which(trip.dist.5$Purpose=="HBW")
## hbo.5 = which(trip.dist.5$Purpose=="HBO")
## hbo.1 = which(trip.dist.1$Purpose=="HBO")
## #line 801 "Travel-Modeling-With-R.Rnw"


## #line 804 "Travel-Modeling-With-R.Rnw"
## #line 749 "Travel-Modeling-With-R.Rnw#from line#804#"
## plot(trip.dist.1[hbo.1,2:3],type='o',
##      col="gray",pch=15,cex=0.5,
##      main="HBO Trip Lengths",
##      xlab="Reported Trip Time in Minutes",
## 	 ylab="Daily Trips (1000s)")
## points(trip.dist.5[hbo.5,2:3],type='o',
##        col="blue",pch=16,cex=0.5)
## legend(75,100000,
##        c("5-minute Times","1-minute Times"),
##        col=c("blue","lightgray"),pch=c(16,15),
##        pt.cex=0.5,lty=1)
## #line 805 "Travel-Modeling-With-R.Rnw"


## #line 808 "Travel-Modeling-With-R.Rnw"
## #line 766 "Travel-Modeling-With-R.Rnw#from line#808#"
## plot(trip.dist.5[hbo.5,2:3],type='o',
##      col="blue",pch=16,cex=0.5,
##      main="Trip Length Frequency Distribution",
##      sub="By Purpose, 5-minute Reports Only",
##      ylab="Daily Trips (1000s)")
## points(trip.dist.5[nhb.5,2:3],type='o',
##        col="red",pch=15,cex=0.5)
## points(trip.dist.5[hbw.5,2:3],type='o',
##        col="green",pch=14,cex=0.5)
## legend(90,100000,c("HBO","NHB","HBW"),
##        col=c("blue","red","green"),
##        pch=c(16,15,14),pt.cex=0.5,lty=1)
## #line 809 "Travel-Modeling-With-R.Rnw"


## #line 867 "Travel-Modeling-With-R.Rnw"
## install.packages(c("rgdal","sp"))


## #line 870 "Travel-Modeling-With-R.Rnw"
## # Non-standard repository:
## install.packages("travelr",
##        repos="http://r-forge.r-project.org")


## #line 881 "Travel-Modeling-With-R.Rnw"
## library(rgdal)
## help('readOGR')


## #line 885 "Travel-Modeling-With-R.Rnw"
## example('readOGR')


## #line 898 "Travel-Modeling-With-R.Rnw"
## browseVignettes()


#line 909 "Travel-Modeling-With-R.Rnw"
library(sp)   # spatial data library
load("alx.network.Rdata")   # sample data


#line 916 "Travel-Modeling-With-R.Rnw"
color.study.area <- "#FFFFDD"
road.colors<-data.frame(
    RED=c(0,168,0,230,230,197,180,230,230),
    GREEN=c(197,112,0,0,0,0,180,0,0),
    BLUE=c(255,0,0,0,0,255,180,0,0),
    WIDTH=c(2,2,2,2,2,1,1,2,2),
    TYPE=factor( c("FREEWAY","EXPRESSWAY",
          "HEAVYRAIL",
          "MAJOR","MINOR",
          "COLLECTOR","LOCAL","BRIDGE","RAMP" ) )
    )
road.colors$TYPE<-factor(
        road.colors$TYPE,
        levels=levels(alx.network$FTYPE) )
row.names(road.colors)<-road.colors$TYPE
color.roads<-rgb(
    road.colors[order(road.colors$TYPE),],
    maxColorValue=255 )
scale.pos <- bbox(alx.study.area)[,"min"]+c(100,400)
one.mile <- 1609.344 # meters
half.mile <- one.mile/2
scale.left <- matrix(c(c(0,0,half.mile,half.mile,0),c(0,100,100,0,0)),nrow=5)
scale.left[,1] <- scale.left[,1]+scale.pos["x"]
scale.left[,2] <- scale.left[,2]+scale.pos["y"]
scale.right <- scale.left
scale.right[,1] <- scale.right[,1]+half.mile

scale.bar  <-  function(col="black",textcol="black") {
   polygon(scale.left)
   polygon(scale.right,col=col)
   text(scale.right[2,1],scale.right[2,2],"Miles",pos=3,offset=0.2,col=textcol)
   text(scale.left[2,1], scale.left[2,2], "0",pos=3,offset=0.2,col=textcol)
   text(scale.right[3,1],scale.right[3,2],"1",pos=3,offset=0.2,col=textcol)
}
north.pos <- bbox(alx.study.area)[,"max"]-c(500,750)
north.scale <- 500
scale.north.arrow <- function(x,scale,pos) {
   sna <- coordinates(x)*scale
   sna <- matrix(c(sna[,1]+pos["x"],sna[,2]+pos["y"]),nrow=nrow(sna))
   dimnames(sna) <- list(NULL,c("x","y"))
   sna
}
lna <- lapply(layout.north.arrow()@polygons[[1]]@Polygons,FUN=scale.north.arrow,scale=north.scale,pos=north.pos)
north.arrow <- function(col=NA,textcol="black",border="black") {
   polygon(lna[[1]],col=col,border=border)
   polygon(lna[[2]],col=textcol,border=border)
}
adorn <- function() { north.arrow(); scale.bar(); }

plot(alx.study.zones,col=color.study.area,lty=0)
road.widths <- road.colors$WIDTH[order(road.colors$TYPE)]
plot(alx.network,
     col=color.roads[alx.network$FTYPE],
     lwd=road.widths[alx.network$FTYPE],add=TRUE)
title('Roads in Alexandria, VA')
legend.items <- c(5,4,3,7,2,6)
legend(par('usr')[1],par('usr')[4],
    levels(road.colors$TYPE)[legend.items],
    col=color.roads[legend.items],
    lwd=road.widths[legend.items],
    lty=1,cex=0.7
    )
adorn()


